package com.org.registration.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.registration.Entity.Register;


public interface RegisterRepository extends JpaRepository<Register,Long> {



}
