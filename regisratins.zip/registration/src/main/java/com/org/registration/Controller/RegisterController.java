package com.org.registration.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.registration.Entity.Register;
import com.org.registration.repository.RegisterRepository;

@RestController
@RequestMapping("/api")
public class RegisterController {

	@Autowired
	RegisterRepository registerrepository;
	
	@PostMapping("/register")
	public String createRegister(@RequestBody Register register) {
		 registerrepository.save(register);
		 return  "Registration created in database";
	}
	@GetMapping("/register")
	public ResponseEntity<List<Register>> getRegisters()
	{
		List<Register> reList=new ArrayList<>();
		registerrepository.findAll().forEach(reList::add);
		return new ResponseEntity<List<Register>>(reList,HttpStatus.OK);
	}
	@GetMapping("/register/{id}")
   public ResponseEntity<Register> getRegisterById(@PathVariable long id){
		Optional<Register> re=registerrepository.findById(id);
		if(re.isPresent())
		{
			return new ResponseEntity<Register>(re.get(),HttpStatus.FOUND);
		}else
		{return new ResponseEntity<Register>(re.get(),HttpStatus.NOT_FOUND);
			
		}}
		@PutMapping("/register/{id}")
		public String UpdateRegisterById(@PathVariable long id,@RequestBody Register register)
		{
			Optional<Register> re=registerrepository.findById(id);
			if(re.isPresent())
			{
				Register extstre=re.get();
				extstre.setName(register.getName());
				extstre.setEmail(register.getEmail());
				extstre.setDateOfBirth(register.getDateOfBirth());
				return "Register details against id "+id+" updated";
		}
			else
			{
				return "register details does not exist for id "+id;
			}
		}
		@DeleteMapping("/register/{id}")
		public String deleteRegisterById(@PathVariable Long id)
		{
			registerrepository.deleteById(id);
			return "Regsiter deleted successfully";
		}
}
